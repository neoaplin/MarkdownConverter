//
//  MarkdownConverterApp.swift
//  MarkdownConverter
//
//  Created by Neo Aplin on 2/9/2025.
//

import SwiftUI
import AppKit

@main
struct MarkdownConverterApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        // No main window for this utility. A Settings scene can be added later.
        Settings { EmptyView() }
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    private var statusItem: NSStatusItem!
    private let converter = ClipboardMarkdownConverter()

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)

        // Create the status bar item
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)

        if let button = statusItem.button {
            if let image = NSImage(named: "MenuBarIcon") {  // <- Change this name
                image.isTemplate = true // This makes it adapt to light/dark mode
                button.image = image
            } else {
                button.title = "MD"  // Fallback if image not found
            }
            button.toolTip = "Convert clipboard to Markdown"
        }
        
        // Build the menu
        let menu = NSMenu()

        let convertItem = NSMenuItem(
            title: "Convert to Markdown",
            action: #selector(convertNow),
            keyEquivalent: ""
        )
        convertItem.target = self
        menu.addItem(convertItem)

        menu.addItem(.separator())

        let quitItem = NSMenuItem(
            title: "Quit",
            action: #selector(NSApp.terminate(_:)),
            keyEquivalent: "q"
        )
        menu.addItem(quitItem)

        statusItem.menu = menu
    }

    @objc private func convertNow() {
        print("Starting conversion...")
        converter.convertClipboardToMarkdown { result in
            switch result {
            case .success:
                print("Conversion successful!")
                // You could add a subtle notification here if desired
                break
            case .failure(let error):
                print("Conversion failed: \(error)")
                Self.showBriefAlert(
                    title: "Couldn't convert clipboard",
                    message: error.localizedDescription
                )
            }
        }
    }

    private static func showBriefAlert(title: String, message: String) {
        DispatchQueue.main.async {
            let alert = NSAlert()
            alert.alertStyle = .warning
            alert.messageText = title
            alert.informativeText = message
            // Ensure the alert appears for a UIElement app
            NSApp.activate(ignoringOtherApps: true)
            alert.runModal()
        }
    }
}
